package com.ponsun.cms.excelimport.service;

import com.ponsun.cms.commonSearch.data.SearchDto;
import com.ponsun.cms.commonSearch.services.CommonSearchReadService;
import com.ponsun.cms.excelimport.dto.ExcelDataDto;
import com.ponsun.cms.excelimport.entity.ExcelData;
import com.ponsun.cms.excelimport.repository.ExcelDataRepository;
import com.ponsun.cms.infrastructure.exceptions.EQAS_CMS_ApplicationException;
import com.ponsun.cms.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static java.lang.Double.parseDouble;

@Service
@Slf4j
@RequiredArgsConstructor
public class ExcelDataCommandService {
    private final ExcelDataRepository excelDataRepository;
    private final CommonSearchReadService searchReadService;

    public ExcelData save(ExcelDataDto input) {
        ExcelData excelData = new ExcelData();
        excelData.setName(input.getName());
        excelData.setType(input.getType());
        excelData.setScore(input.getScore());
        excelData.setCountry(input.getCountry());
        return excelDataRepository.save(excelData);
    }

    @Transactional
    public Response saveBulkData(List<Map<String, Object>> rows) {
        try {
            long totalRecordSaved = 0L;
            long startTime = System.currentTimeMillis();

            List<SearchDto> searchDTOList = new ArrayList<>();

            for (Map<String, Object> row : rows) {
                final String name = ((String) row.get("name")).trim();
                String score = ((String) row.get("score"));
//                final String type = ((String) row.get("type")).trim();
//                final String country = ((String) row.get("country")).trim();
                double searchScore  = parseDouble(score);

                SearchDto searchDTO = new SearchDto();
                searchDTO.setName(name);
                searchDTO.setSearchingScore(searchScore);
                searchDTOList.add(searchDTO);
                totalRecordSaved = totalRecordSaved + 1;
            }
            this.searchReadService.getRecords(searchDTOList);

//            for (SearchDto searchDTO : searchDTOList) {
//                CreateSearchDetailsRequest createSearchDetailsRequest = new CreateSearchDetailsRequest();
//                createSearchDetailsRequest.setName(searchDTO.getName());
//                createSearchDetailsRequest.setSearchingScore(searchDTO.getSearchingScore());
//                searchDetailsWritePlatformService.createSearchDetails(createSearchDetailsRequest);
//            }


//            List<OFACData> ofacdataList = this.ofacsearchService.fetchAllOFACData();
//            this.excelReadService.calculateScore(searchDTOList, ofacdataList);
//            long endTime = System.currentTimeMillis();
//            System.out.println("Total milli seconds taken " + (endTime - startTime));
            return new Response(totalRecordSaved);

        } catch (DataIntegrityViolationException e) {
            log.error("Error while saveBulkData {}", e.getMessage());
            throw new EQAS_CMS_ApplicationException(e.getMessage());
        }
    }

}
