package com.ponsun.cms.commonSearch.data;

import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class RecordsDto {
    private Integer cmsId;
    private Integer searchId;
    private Integer criminalId;
    private Integer hitId;
    private String cmsName;
    private String cmsRecordType;
    private Double score;
    private Integer recordTypeId;
    public RecordsDto(Integer cmsId,Integer searchId,Integer criminalId,Integer hitId, String cmsName, String cmsRecordType, Double score ,Integer recordTypeId ) {
        this.cmsId = cmsId;
        this.searchId = searchId;
        this.criminalId = criminalId;
        this.hitId = hitId;
        this.cmsName = cmsName;
        this.cmsRecordType = cmsRecordType;
        this.score = score;
    }

    public static RecordsDto newInstance(Integer cmsId,Integer searchId,Integer criminalId,Integer hitId, String cmsName, String cmsRecordType, Double score,Integer recordTypeId ) {
        return new RecordsDto(cmsId,searchId,criminalId,hitId, cmsName, cmsRecordType, score,recordTypeId);
    }
}
