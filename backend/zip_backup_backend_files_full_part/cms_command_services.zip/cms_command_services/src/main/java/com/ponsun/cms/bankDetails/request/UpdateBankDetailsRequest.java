package com.ponsun.cms.bankDetails.request;

import lombok.Data;

@Data
public class UpdateBankDetailsRequest extends AbstractBankDetailsRequest {
    @Override
    public String toString(){ return super.toString();}
}
