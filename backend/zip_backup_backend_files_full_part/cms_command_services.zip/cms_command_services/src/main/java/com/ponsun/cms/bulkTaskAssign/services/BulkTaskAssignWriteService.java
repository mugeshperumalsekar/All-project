package com.ponsun.cms.bulkTaskAssign.services;



import com.ponsun.cms.searchLifcycle.HitRecord.data.HitRecordData;
import com.ponsun.cms.bulkTaskAssign.request.CreateBulkTaskAssignRequest;
import com.ponsun.cms.bulkTaskAssign.request.UpdateBulkTaskAssignRequest;
import com.ponsun.cms.infrastructure.utils.Response;

import java.util.List;

public interface BulkTaskAssignWriteService {
    Response createBulkTaskAssign(CreateBulkTaskAssignRequest createBulkTaskAssignRequest);

    Response updateBulkTaskAssign(Integer id, UpdateBulkTaskAssignRequest updateBulkTaskAssignRequest);

    Response deactive(Integer id, Integer euid);

    List<HitRecordData> fetchAllRecordData(Integer searchId);

    Response createBulkAssign(CreateBulkTaskAssignRequest createBulkTaskAssignRequest);
}
