package com.ponsun.cms.bulkAssignMapping.request;

import lombok.Data;

@Data
public class CreateBulkAssignMappingRequest extends AbstractBulkAssignMappingRequest {
    @Override
    public String toString(){ return super.toString();}
}
