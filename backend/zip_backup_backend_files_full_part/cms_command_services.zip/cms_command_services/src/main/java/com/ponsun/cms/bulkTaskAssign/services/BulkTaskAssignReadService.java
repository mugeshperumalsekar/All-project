package com.ponsun.cms.bulkTaskAssign.services;



import com.ponsun.cms.bulkTaskAssign.domain.BulkTaskAssign;

import java.util.List;

public interface BulkTaskAssignReadService {
    List<BulkTaskAssign> fetchAllBulkTaskAssign();

    BulkTaskAssign fetchBulkTaskAssignById(Integer id);
}
