package com.ponsun.cms.IndOrg.detailsAboutRelation.request;

public class CreateDetailsAboutRelationRequest extends AbstractDetailsAboutRelationRequest {

    @Override
    public String toString() {
        return super.toString();
    }
}
