package com.ponsun.cms.countryRegistration.request;

import lombok.Data;

@Data
public class UpdateCountryRegistrationRequest extends AbstractCountryRegistrationRequest {
    @Override
    public String toString(){ return super.toString();}
}