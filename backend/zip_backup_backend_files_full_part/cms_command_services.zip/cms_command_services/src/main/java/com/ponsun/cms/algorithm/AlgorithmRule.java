package com.ponsun.cms.algorithm;

import com.ponsun.cms.algorithm.cdo.CriminalRuleCDO;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.springframework.stereotype.Service;

@Service
@Slf4j
@RequiredArgsConstructor
public class AlgorithmRule {
    private final KieContainer kieContainer;


    public boolean isCriminalRulePassed(final double value1,final double value2,final double jaroWinkler,final double value4,final double matching_score) {
        final KieSession ruleSession = kieContainer.newKieSession();
        try {
            final CriminalRuleCDO criminalRuleCDO = new CriminalRuleCDO();
            criminalRuleCDO.setScore1(value1);
            criminalRuleCDO.setScore2(value2);
            criminalRuleCDO.setSearchScore(matching_score);
            ruleSession.insert(criminalRuleCDO);
            ruleSession.fireAllRules();

            if(StringUtils.isNoneBlank(criminalRuleCDO.getStatus())
                    && criminalRuleCDO.getStatus().equalsIgnoreCase("success")) {
                return true;
            }
            return false;
        } finally {
            ruleSession.dispose();
        }
    }
}
