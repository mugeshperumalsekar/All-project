package com.ponsun.cms.bulkAssignMapping.services;


import com.ponsun.cms.bulkAssignMapping.data.BulkAssignMappingData;
import com.ponsun.cms.bulkAssignMapping.request.CreateBulkAssignMappingRequest;
import com.ponsun.cms.bulkAssignMapping.request.UpdateBulkAssignMappingRequest;
import com.ponsun.cms.infrastructure.utils.Response;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface BulkAssignMappingWriteService {
    Response createBulkAssignMapping(CreateBulkAssignMappingRequest createBulkAssignMappingRequest);

    Response updateBulkAssignMapping(Integer id, UpdateBulkAssignMappingRequest updateBulkAssignMappingRequest);

    Response deactive(Integer id, Integer euid);

    List<BulkAssignMappingData> fetchAllRecordData(Integer searchId);

    List<BulkAssignMappingData> getHitRecordsBySearchId(Integer searchId);
}
