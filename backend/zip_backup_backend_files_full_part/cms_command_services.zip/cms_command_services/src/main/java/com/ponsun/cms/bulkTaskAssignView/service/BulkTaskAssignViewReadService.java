package com.ponsun.cms.bulkTaskAssignView.service;



import com.ponsun.cms.bulkTaskAssignView.data.BulkTaskAssignViewData;

import java.util.List;

public interface BulkTaskAssignViewReadService {
    List<BulkTaskAssignViewData> fetchAllBulkTaskAssignView(Integer uid);
}
