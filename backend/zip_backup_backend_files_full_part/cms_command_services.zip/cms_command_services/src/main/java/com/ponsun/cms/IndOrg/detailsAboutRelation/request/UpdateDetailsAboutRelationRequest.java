package com.ponsun.cms.IndOrg.detailsAboutRelation.request;

public class UpdateDetailsAboutRelationRequest extends AbstractDetailsAboutRelationRequest {

    @Override
    public String toString() {
        return super.toString();
    }
}
