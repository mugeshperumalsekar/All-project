package com.ponsun.cms.algorithm.dto;

import com.ponsun.cms.searchLifcycle.HitRecord.request.CreateHitRecordRequest;
import com.ponsun.cms.searchLifcycle.HitRecord.services.HitRecordWritePlatformService;
import com.ponsun.cms.SearchDetails.Search.request.CreateSearchRequest;
import com.ponsun.cms.SearchDetails.Search.services.SearchWritePlatformService;
import com.ponsun.cms.SearchDetails.SearchDetails.services.SearchDetailsWritePlatformService;
import com.ponsun.cms.algorithm.cdo.CriminalRuleCDO;
import com.ponsun.cms.commonDetails.data.StatusDetailsData;
import com.ponsun.cms.commonSearch.data.RecordsDto;
import com.ponsun.cms.commonSearch.data.SearchDto;
import com.ponsun.cms.infrastructure.utils.Response;

import com.ponsun.cms.uiTest.AlgorithmTesting.ExactMatch.ExactMatch;
import com.ponsun.cms.uiTest.AlgorithmTesting.Jaro.Jarowinkler_Match;
import com.ponsun.cms.uiTest.AlgorithmTesting.Oneside.Oneside;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.kie.api.runtime.KieContainer;
import org.kie.api.runtime.KieSession;
import org.modelmapper.ModelMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class ScoreCalculate {
    private final KieContainer kieContainer;
    private final SearchWritePlatformService searchWritePlatformService;
    private final HitRecordWritePlatformService hitRecordWritePlatformService;

    @Transactional
    public List<RecordsDto> calculateScore(SearchDto searchDTO, List<StatusDetailsData> statusDetailsDataList) {
        List<RecordsDto> recordDTOS = new ArrayList<>();
        List<RecordsDto> listOfArrays = new ArrayList<>();


        String queryCustomer    = sanitizeString(searchDTO.getName());
        Double matching_score   = searchDTO.getSearchingScore();

        ModelMapper modelMapper = new ModelMapper();
        CreateSearchRequest request = modelMapper.map(searchDTO, CreateSearchRequest.class);
        request.setMatchingScore(matching_score);
        Response response = this.searchWritePlatformService.createSearch(request);
        Integer searchId = (Integer) response.getId();

        for (StatusDetailsData statusDetailsData : statusDetailsDataList) {

            String str2 = sanitizeString(statusDetailsData.getCmsName());

            double value1 = Oneside.onesideMatching(queryCustomer, str2);
            double value2 = ExactMatch.ExactMatching(queryCustomer, str2);
            double value3 = Jarowinkler_Match.getJarowinklerMatching(queryCustomer, str2);

            boolean isCriminalScoreVerified = isCriminalRulePassed(value1, value2,value3, matching_score);
            if (isCriminalScoreVerified) {
                RecordsDto recordDTO = new RecordsDto();
                recordDTO.setCmsId(statusDetailsData.getCmsId());
                recordDTO.setCmsName(statusDetailsData.getCmsName());
                recordDTO.setCmsRecordType(statusDetailsData.getCmsRecordType());
                recordDTO.setRecordTypeId(statusDetailsData.getRecordTypeId());
                recordDTO.setScore(Math.max(Math.max(value1, value2 ),value3));
                recordDTO.setCriminalId(statusDetailsData.getCmsId());
                recordDTO.setSearchId(searchId);
                listOfArrays.add(recordDTO);
            }
        }

        Collections.sort(listOfArrays, Comparator.comparingDouble(RecordsDto::getScore));
        Map<Integer, RecordsDto> map = new HashMap<>();
        for (RecordsDto array : listOfArrays) {
            int uniqueValue = array.getCmsId();
            map.put(uniqueValue, array);
        }
        List<RecordsDto> uniqueListOfArrays = new ArrayList<>(map.values());

        for (RecordsDto array : uniqueListOfArrays) {
            RecordsDto recordDTO = new RecordsDto();
            CreateHitRecordRequest request1 = new CreateHitRecordRequest();

            request1.setName(array.getCmsName());
            request1.setSearchId(searchId);
            request1.setCriminalId(array.getCmsId());
            request1.setDisplay("P" + array.getCmsId());
            request1.setMatchingScore(array.getScore());
            request1.setCycleId(1);
            request1.setStatusNowId(0);

            Response hitResponse = hitRecordWritePlatformService.createHitRecord(request1);
            Integer hitRecId = (Integer) hitResponse.getId();

            recordDTO.setCmsId(array.getCmsId());
            recordDTO.setCmsName(array.getCmsName());
            recordDTO.setRecordTypeId(array.getRecordTypeId());
            recordDTO.setCriminalId(array.getCmsId());
            recordDTO.setSearchId(searchId);
            recordDTO.setHitId(hitRecId);
            recordDTO.setScore(array.getScore());
            recordDTOS.add(recordDTO);
        }

        Collections.sort(recordDTOS, Comparator.comparingDouble(RecordsDto::getScore).reversed());
        return recordDTOS;
    }
    public String sanitizeString(String input) {

        String str  =  input.replace("-"," ");
        return str.replaceAll(",", " ")
                .replaceAll("[^a-zA-Z0-9\\s]", "")
                .replaceAll("[-+^]*", "")
                .replaceAll("_"," ")
                .toLowerCase();
    }
    private boolean isCriminalRulePassed(final double value1, final double value2, final double value3, final double matching_score) {
        final KieSession ruleSession = kieContainer.newKieSession();
        try {
            final CriminalRuleCDO criminalRuleCDO = new CriminalRuleCDO();
            criminalRuleCDO.setScore1(value1);
            criminalRuleCDO.setScore2(value2);
            criminalRuleCDO.setScore3(value3);

            criminalRuleCDO.setSearchScore(matching_score);
            ruleSession.insert(criminalRuleCDO);
            ruleSession.fireAllRules();

            if (StringUtils.isNoneBlank(criminalRuleCDO.getStatus()) && criminalRuleCDO.getStatus().equalsIgnoreCase("success")) {
                return true;
            }
            return false;
        } finally {
            ruleSession.dispose();
        }
    }
}