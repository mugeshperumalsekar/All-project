package com.ponsun.cms.commonSearch.data;
import lombok.Data;
import lombok.RequiredArgsConstructor;

@Data
@RequiredArgsConstructor
public class SearchDto {
    private String name;
    private double searchingScore;
    private Integer recordTypeId;
    private Integer uid;
    private Integer kycId;
    private Integer applicantFormId;
    private Integer screeningType;
    private Integer isScreening;

    private SearchDto(String name,Integer recordTypeId, double searchingScore,  Integer uid, Integer kycId, Integer applicantFormId, Integer screeningType, Integer isScreening) {
        this.name = name;
        this.recordTypeId=recordTypeId;
        this.searchingScore = searchingScore;
        this.uid = uid;
        this.kycId = kycId;
        this.applicantFormId = applicantFormId;
        this.screeningType = screeningType;
        this.isScreening = isScreening;
    }

    public static SearchDto newInstance(String name,Integer recordTypeId, double searchingScore, Integer uid, Integer kycId, Integer applicantFormId, Integer screeningType, Integer isScreening) {
        return new SearchDto(name,recordTypeId, searchingScore, uid, kycId, applicantFormId, screeningType, isScreening);
    }
}
