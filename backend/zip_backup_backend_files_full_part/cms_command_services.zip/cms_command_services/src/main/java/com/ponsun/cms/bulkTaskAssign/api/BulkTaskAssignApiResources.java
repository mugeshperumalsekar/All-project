package com.ponsun.cms.bulkTaskAssign.api;


import com.ponsun.cms.searchLifcycle.HitRecord.data.HitRecordData;
import com.ponsun.cms.bulkTaskAssign.domain.BulkTaskAssign;
import com.ponsun.cms.bulkTaskAssign.request.CreateBulkTaskAssignRequest;
import com.ponsun.cms.bulkTaskAssign.request.UpdateBulkTaskAssignRequest;
import com.ponsun.cms.bulkTaskAssign.services.BulkTaskAssignReadService;
import com.ponsun.cms.bulkTaskAssign.services.BulkTaskAssignWriteService;
import com.ponsun.cms.infrastructure.utils.Response;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("api/v1/BulkTaskAssign")
@Tag(name = "BulkTaskAssignApiResource")

public class BulkTaskAssignApiResources {
    private final BulkTaskAssignWriteService bulkTaskAssignWriteService;
    private final BulkTaskAssignReadService bulkTaskAssignReadService;

    @PostMapping("/createBulkTaskAssign")
    public Response saveBulkTaskAssign(@RequestBody CreateBulkTaskAssignRequest createBulkTaskAssignRequest) {
        log.debug("START saveBulkTaskAssign request body {}", createBulkTaskAssignRequest);
        Response response = this.bulkTaskAssignWriteService.createBulkTaskAssign(createBulkTaskAssignRequest);
        log.debug("START saveBulkTaskAssign response", response);
        return response;
    }

    @GetMapping
    public List<BulkTaskAssign> fetchAll() {
        return this.bulkTaskAssignReadService.fetchAllBulkTaskAssign();
    }

//    @GetMapping("/{id}")
//    public BulkTaskAssign fetchAllBulkTaskAssignById(@PathVariable Integer id) {
//        return this.bulkTaskAssignReadService.fetchBulkTaskAssignById(id);
//    }

    @PutMapping("/{id}")
    public Response updateBulkTaskAssign(@PathVariable Integer id, @RequestBody UpdateBulkTaskAssignRequest updateBulkTaskAssignRequest) {
        log.debug("START updateBulkTaskAssign request body {}", updateBulkTaskAssignRequest);
        Response response = this.bulkTaskAssignWriteService.updateBulkTaskAssign(id, updateBulkTaskAssignRequest);
        log.debug("START updateBulkTaskAssign response", response);
        return response;
    }

    @PutMapping("/deactive/{id}")
    public Response deactive(@PathVariable Integer id, Integer euid) {
        Response response = this.bulkTaskAssignWriteService.deactive(id, euid);
        return response;
    }

//    @GetMapping("/{searchId}")
//    public List<BulkTaskAssignData> fetchAllRecordData(@PathVariable Integer searchId) {
//        return this.bulkTaskAssignWriteService.fetchAllRecordData(searchId);
//    }

    @GetMapping("/{searchId}")
    public List<HitRecordData> fetchAllRecordData(@RequestParam Integer searchId) {
        return this.bulkTaskAssignWriteService.fetchAllRecordData(searchId);
    }

    @PostMapping("/createBulkAssign")
    public Response saveBulkAssign(@RequestBody CreateBulkTaskAssignRequest createBulkTaskAssignRequest) {
        log.debug("START saveBulkTaskAssign request body {}", createBulkTaskAssignRequest);
        Response response = this.bulkTaskAssignWriteService.createBulkAssign(createBulkTaskAssignRequest);
        log.debug("START saveBulkTaskAssign response", response);
        return response;
    }

}
