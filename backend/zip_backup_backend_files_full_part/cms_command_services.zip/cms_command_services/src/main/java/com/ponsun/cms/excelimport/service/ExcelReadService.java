package com.ponsun.cms.excelimport.service;
import java.util.List;
public interface ExcelReadService {
    List<Integer> fetchHitIds(Integer searchId);
}
