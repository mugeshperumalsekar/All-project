package com.ponsun.cms.IndCaseDetails.request;

import lombok.Data;

@Data
public class CreateIndCaseDetailsRequest extends AbstractIndCaseDetailsRequest {
    @Override
    public String toString(){ return super.toString();}
}
