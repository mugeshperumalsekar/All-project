package com.ponsun.cms.commonSearch.api;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ponsun.cms.commonSearch.data.RecordsDto;
import com.ponsun.cms.commonSearch.data.ScreeningDto;
import com.ponsun.cms.commonSearch.data.SearchDto;
import com.ponsun.cms.commonSearch.services.CommonSearchReadService;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@Slf4j
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/v1/ScreeningRecords")
@Tag(name = "ScreeningRecordsApiResources")
public class CommonSearchApiResources {
    private final CommonSearchReadService commonSearchReadService;
    @GetMapping("/Screening")
    public List<RecordsDto> getRecords(@RequestParam("ScreeningDto") String screeningDto) throws JsonProcessingException {
        ObjectMapper objectMapper = new ObjectMapper();
        ScreeningDto screeningConvertedDto = objectMapper.readValue(screeningDto, ScreeningDto.class);
        List<SearchDto> searchDto = screeningConvertedDto.getSearchDto();
        return this.commonSearchReadService.getRecords(searchDto);
    }
}
