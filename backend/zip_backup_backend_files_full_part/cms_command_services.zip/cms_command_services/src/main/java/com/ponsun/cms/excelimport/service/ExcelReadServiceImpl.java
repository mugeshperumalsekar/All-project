package com.ponsun.cms.excelimport.service;


import com.ponsun.cms.EhcachePOC.Data.OFACData;

import com.ponsun.cms.searchLifcycle.HitRecord.services.HitRecordWritePlatformService;
import com.ponsun.cms.SearchDetails.Search.request.CreateSearchRequest;
import com.ponsun.cms.SearchDetails.Search.services.SearchWritePlatformService;
import com.ponsun.cms.algorithm.ScoringCalculatorService;
import com.ponsun.cms.dto.RecordDTO;
import com.ponsun.cms.dto.ScreenDTO;
import com.ponsun.cms.dto.SearchDTO;
import com.ponsun.cms.infrastructure.utils.Response;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.modelmapper.ModelMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.concurrent.ExecutionException;

@Service
@RequiredArgsConstructor
@Slf4j
public class ExcelReadServiceImpl implements ExcelReadService {
    private final JdbcTemplate jdbcTemplate;

    @Override
    public List<Integer> fetchHitIds(Integer searchId) {
        String Qry = "SELECT id FROM hitrecord WHERE searchId = ?";
        List<Integer> hitIds = jdbcTemplate.query(Qry, new Object[]{searchId}, (rs, rowNum) -> rs.getInt("id"));
        log.info("Fetched hitIds: {}", hitIds);
        return hitIds;
    }
}

