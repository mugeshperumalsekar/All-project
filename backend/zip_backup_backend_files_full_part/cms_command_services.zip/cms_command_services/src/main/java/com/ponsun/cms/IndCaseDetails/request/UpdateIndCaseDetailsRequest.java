package com.ponsun.cms.IndCaseDetails.request;

import lombok.Data;

@Data
public class UpdateIndCaseDetailsRequest extends AbstractIndCaseDetailsRequest {
    @Override
    public String toString(){ return super.toString();}
}
