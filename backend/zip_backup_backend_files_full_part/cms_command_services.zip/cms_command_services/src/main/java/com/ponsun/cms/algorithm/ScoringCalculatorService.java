package com.ponsun.cms.algorithm;

import com.ponsun.cms.EhcachePOC.Data.OFACData;
import com.ponsun.cms.searchLifcycle.HitRecord.domain.HitRecord;
import com.ponsun.cms.searchLifcycle.HitRecord.domain.HitRecordRepository;
import com.ponsun.cms.searchLifcycle.HitRecord.request.CreateHitRecordRequest;
import com.ponsun.cms.searchLifcycle.HitRecord.services.HitRecordWritePlatformService;
import com.ponsun.cms.dto.RecordDTO;
import com.ponsun.cms.ofac.Count.service.RecordDetails;
import com.ponsun.cms.ofac.Count.service.RecordReadService;
import com.ponsun.cms.uiTest.AlgorithmTesting.ExactMatch.ExactMatch;
import com.ponsun.cms.uiTest.AlgorithmTesting.Fuzzy.Fuzzy_WeightedRatio;
import com.ponsun.cms.uiTest.AlgorithmTesting.Jaro.Jarowinkler_Match;
import com.ponsun.cms.uiTest.AlgorithmTesting.Oneside.Oneside;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class ScoringCalculatorService {

    private final AlgorithmRule algorithmRule;
    private final HitRecordWritePlatformService hitRecordWritePlatformService;
    private final RecordReadService recordReadService;
    private final RecordDetails recordDetailsComponent;
    private final HitRecordRepository hitDataRepository;

    @Async("asyncExecutor")
    public Future<List<RecordDTO>> calculatenamewiseScore(String queryCustomer, double matchingScore, Integer searchId, List<OFACData> countDataList) {

        String finalQueryCustomer = sanitizeString(queryCustomer);

        List<RecordDTO> listOfArrays = countDataList.parallelStream()
                .map(countData -> {
                    try {
                        String sanitizedName = sanitizeString(countData.getName());
                        double[] scores = calculateScores(finalQueryCustomer, sanitizedName);

                        if (algorithmRule.isCriminalRulePassed(scores[0], scores[1], scores[2], scores[3], matchingScore)) {
                            double maxScore = findMaxScore(scores);
                            return createRecordDTO(countData, searchId, maxScore);
                        }

                        return null;
                    } catch (Exception e) {
                        return null;
                    }
                })
                .filter(recordDTO -> recordDTO != null)
                .collect(Collectors.toList());
        return new AsyncResult<>(listOfArrays);
    }

    private String sanitizeString(String input) {
        return input.replaceAll(",", " ")
                .replaceAll("[^a-zA-Z0-9\\s]", "")
                .replaceAll("[-+^]*", "")
                .toLowerCase();
    }

    private double[] calculateScores(String queryCustomer, String str2) {
        double[] scores = new double[4];
        scores[0] = safeCalculate(() -> round(Oneside.onesideMatching(queryCustomer, str2), 0), "oneside", queryCustomer, str2);
        scores[1] = safeCalculate(() -> round(ExactMatch.ExactMatching(queryCustomer, str2), 0), "exactMatch", queryCustomer, str2);
        scores[2] = safeCalculate(() -> round(Jarowinkler_Match.getJarowinklerMatching(queryCustomer, str2), 0), "Jarowinkler_Match", queryCustomer, str2);
        scores[3] = safeCalculate(() -> round(Fuzzy_WeightedRatio.Fuzzy_WeightedRatio(queryCustomer, str2), 0), "Fuzzy_WeightedRatio", queryCustomer, str2);
        return scores;
    }

    private double safeCalculate(Supplier<Double> calculation, String type, String queryCustomer, String str2) {
        try {
            return calculation.get();
        } catch (IndexOutOfBoundsException e) {
            System.out.println(type + ":" + queryCustomer + " " + str2 + "  " + e);
            return 0;
        }
    }

    private double findMaxScore(double[] scores) {
        double maxScore = scores[0];
        for (double score : scores) {
            if (score > maxScore) {
                maxScore = score;
            }
        }
        return maxScore;
    }

    private RecordDTO createRecordDTO(OFACData countData, Integer searchId, double score) {
        RecordDTO recordDTO = new RecordDTO();
        recordDTO.setIds(countData.getId());
        recordDTO.setNAME(countData.getName());
        recordDTO.setFileList(countData.getFileList());
        recordDTO.setFileType(countData.getFileType());
        recordDTO.setCriminalId(countData.getId());
        recordDTO.setSearchId(searchId);
        recordDTO.setScore(score);
        return recordDTO;
    }

    private double round(double value, int places) {
        return value;
    }

    @FunctionalInterface
    private interface Supplier<T> {
        T get() throws IndexOutOfBoundsException;
    }

    public List<RecordDTO> processAndSaveRecords(List<RecordDTO> recordDTOList, Integer searchId) {
        List<HitRecord> hitRecords = new ArrayList<>();
        for (RecordDTO addressDTO : recordDTOList) {
            hitRecords.add(processRecordDTO(searchId, addressDTO));
        }


        List<HitRecord> savedHitRecords = new ArrayList<>();
        savedHitRecords = this.hitDataRepository.saveAll(hitRecords);
        System.out.println("savedHitRecords" + savedHitRecords);

        List<RecordDTO> newRecordDTO = new ArrayList<>();

        try {
            updateRecordDTOIfNeeded(savedHitRecords, newRecordDTO);
        } catch (ExecutionException e) {
            throw new RuntimeException(e);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

        return newRecordDTO;
    }

    private HitRecord processRecordDTO(Integer searchId, RecordDTO recordDTO) {
        CreateHitRecordRequest request = createHitRecordRequest(searchId, recordDTO);
        HitRecord hitRecord = HitRecord.create(request);
        return hitRecord;
    }

    private CreateHitRecordRequest createHitRecordRequest(Integer searchId, RecordDTO recordDTO) {
        CreateHitRecordRequest request = new CreateHitRecordRequest();

        request.setName(recordDTO.getNAME());
        request.setSearchId(searchId);
        request.setCriminalId(recordDTO.getIds());
        request.setDisplay("P" + recordDTO.getIds());
        request.setFileType(recordDTO.getFileType());
        request.setMatchingScore(recordDTO.getScore());
        request.setCycleId(1);
        request.setStatusNowId(0);

        return request;
    }

    private RecordDTO copyProperties(RecordDTO source) {
        RecordDTO target = new RecordDTO();
        target.setIds(source.getIds());
        target.setSearchId(source.getSearchId());
        target.setCriminalId(source.getIds());
        target.setNAME(source.getNAME());
        target.setFileType(source.getFileType());
        target.setFileList(source.getFileList());
        target.setScore(source.getScore());
        return target;
    }

    private void updateRecordDTOIfNeeded(List<HitRecord> source, List<RecordDTO> target) throws ExecutionException, InterruptedException {
        recordReadService.updateRecordDTO(recordDetailsComponent, source, target);
    }

    private RecordDTO getFutureResult(Future<RecordDTO> future) {
        try {
            return future.get();
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
            return null;
        }
    }
}