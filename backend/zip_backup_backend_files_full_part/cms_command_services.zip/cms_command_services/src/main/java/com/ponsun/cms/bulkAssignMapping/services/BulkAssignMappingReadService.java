package com.ponsun.cms.bulkAssignMapping.services;



import com.ponsun.cms.bulkAssignMapping.domain.BulkAssignMapping;

import java.util.List;

public interface BulkAssignMappingReadService {
    List<BulkAssignMapping> fetchAllBulkAssignMapping();

    BulkAssignMapping fetchBulkAssignMappingById(Integer id);
}
