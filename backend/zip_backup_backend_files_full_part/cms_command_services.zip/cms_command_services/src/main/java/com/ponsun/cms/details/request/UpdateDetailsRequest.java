package com.ponsun.cms.details.request;

import lombok.Data;

@Data
public class UpdateDetailsRequest extends AbstractDetailsRequest {
    @Override
    public String toString(){ return super.toString();}
}
