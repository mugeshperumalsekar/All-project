package com.ponsun.cms.entityScreening.services;



import com.ponsun.cms.entityScreening.data.EntityScreeningData;

import java.util.List;

public interface EntityScreeningWritePlatformService {
    List<EntityScreeningData> fetchAllEntityScreening(Integer kycId);
}
