package com.ponsun.cms.commonSearch.services;


import com.ponsun.cms.commonSearch.data.RecordsDto;
import com.ponsun.cms.commonSearch.data.SearchDto;

import java.util.ArrayList;
import java.util.List;

public interface CommonSearchReadService {
    List<RecordsDto> getRecords(List<SearchDto> searchDto);

}
