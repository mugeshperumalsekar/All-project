package com.ponsun.cms.EhcachePOC.Service;

import com.ponsun.cms.EhcachePOC.Data.RecordDetailData;

import java.util.List;

public interface OFACDetailService {
    List<RecordDetailData> fetchTestingData();
    List<RecordDetailData> fetchTestingDataById(Integer id);

}
