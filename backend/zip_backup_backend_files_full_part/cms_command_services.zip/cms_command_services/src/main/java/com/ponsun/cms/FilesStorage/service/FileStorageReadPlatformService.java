package com.ponsun.cms.FilesStorage.service;

public interface FileStorageReadPlatformService {


}
