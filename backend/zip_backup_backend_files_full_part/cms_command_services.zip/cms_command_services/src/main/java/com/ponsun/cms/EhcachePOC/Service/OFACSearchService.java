package com.ponsun.cms.EhcachePOC.Service;

import com.ponsun.cms.EhcachePOC.Data.OFACData;

import java.util.List;

public interface OFACSearchService {

    List<OFACData> fetchAllOFACData();
    String deleteOfacData();
}
