package com.ponsun.cms.countryHq.request;

import lombok.Data;

@Data
public class CreateCountryHqRequest extends AbstractCountryHqRequest {
    @Override
    public String toString(){ return super.toString();}
}
