package com.ponsun.cms.commonSearch.services;

import com.ponsun.cms.algorithm.dto.ScoreCalculate;
import com.ponsun.cms.commonDetails.data.StatusDetailsData;
import com.ponsun.cms.commonDetails.services.CommonDetailsReadService;
import com.ponsun.cms.commonSearch.data.RecordsDto;
import com.ponsun.cms.commonSearch.data.SearchDto;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class CommonSearchReadServiceImpl implements CommonSearchReadService {

    private final ScoreCalculate scoreCalculate;
    final private CommonDetailsReadService commonDetailsReadService;

    @Override
    @Transactional
    public List<RecordsDto> getRecords(List<SearchDto> searchDto) {
        try {
            List<RecordsDto> recordDTOList = new ArrayList<>();
            Integer kyc = 0;

                if (searchDto != null && !searchDto.isEmpty()) {
                 kyc = searchDto.get(0).getKycId();
                }

            List<StatusDetailsData> statusDetailsData = new ArrayList<>();
            if(kyc!=0 )
                statusDetailsData = this.commonDetailsReadService.fetchAllData(0);

            for (SearchDto searchDto1:searchDto) {
            Integer recordTypeId = searchDto1.getRecordTypeId();
                if(kyc==0 )
                    statusDetailsData = this.commonDetailsReadService.fetchAllData(recordTypeId);

                recordDTOList.addAll(this.scoreCalculate.calculateScore(searchDto1, statusDetailsData));
            }
//            System.out.println(recordDTOList);
            return recordDTOList;
        } catch (DataAccessException e) {
            System.err.println("Error getTotalRecordsCount: " + e.getMessage());
            e.printStackTrace();
        }
        return null;
    }
}