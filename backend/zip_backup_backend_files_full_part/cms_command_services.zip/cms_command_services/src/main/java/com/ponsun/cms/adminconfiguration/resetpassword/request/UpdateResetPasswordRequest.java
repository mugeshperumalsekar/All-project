package com.ponsun.cms.adminconfiguration.resetpassword.request;

import lombok.Data;

@Data
public class UpdateResetPasswordRequest extends AbstractResetPasswordBaseRequest {
    @Override
    public String toString() {
        return super.toString();
    }

}
