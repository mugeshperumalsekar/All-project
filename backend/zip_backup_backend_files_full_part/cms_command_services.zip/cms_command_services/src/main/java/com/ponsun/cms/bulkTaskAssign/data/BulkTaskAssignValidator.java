package com.ponsun.cms.bulkTaskAssign.data;



import com.ponsun.cms.bulkTaskAssign.request.CreateBulkTaskAssignRequest;
import com.ponsun.cms.bulkTaskAssign.request.UpdateBulkTaskAssignRequest;
import com.ponsun.cms.infrastructure.exceptions.EQAS_CMS_ApplicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BulkTaskAssignValidator {
    public void validateSaveBulkTaskAssign(final CreateBulkTaskAssignRequest request){
        if(request.getAssignTo() == null || request.getAssignTo().equals("")){
            throw  new EQAS_CMS_ApplicationException("BulkTaskAssignTo parameter required");
        }
    }

    public void validateUpdateBulkTaskAssign(final UpdateBulkTaskAssignRequest request){
        if(request.getAssignTo() == null || request.getAssignTo().equals("")){
            throw new EQAS_CMS_ApplicationException("BulkTaskAssignTo parameter required");
        }
    }
}
