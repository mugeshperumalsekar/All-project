package com.ponsun.cms.bulkTaskAssign.services;



import com.ponsun.cms.searchLifcycle.HitRecord.data.HitRecordData;
import com.ponsun.cms.searchLifcycle.HitRecord.rowmapper.HitRecordRowMapper;
import com.ponsun.cms.bulkAssignMapping.data.BulkAssignMappingData;
import com.ponsun.cms.bulkAssignMapping.data.BulkAssignMappingValidator;
import com.ponsun.cms.bulkAssignMapping.domain.BulkAssignMapping;
import com.ponsun.cms.bulkAssignMapping.domain.BulkAssignMappingRepository;
import com.ponsun.cms.bulkAssignMapping.request.CreateBulkAssignMappingRequest;
import com.ponsun.cms.bulkAssignMapping.services.BulkAssignMappingWriteService;
import com.ponsun.cms.bulkTaskAssign.data.BulkTaskAssignValidator;
import com.ponsun.cms.bulkTaskAssign.domain.BulkTaskAssign;
import com.ponsun.cms.bulkTaskAssign.domain.BulkTaskAssignRepository;
import com.ponsun.cms.bulkTaskAssign.domain.BulkTaskAssignWrapper;
import com.ponsun.cms.bulkTaskAssign.request.CreateBulkTaskAssignRequest;
import com.ponsun.cms.bulkTaskAssign.request.UpdateBulkTaskAssignRequest;
import com.ponsun.cms.common.entity.Status;
import com.ponsun.cms.dto.RecordDTO;
import com.ponsun.cms.excelimport.service.ExcelReadService;
import com.ponsun.cms.infrastructure.exceptions.EQAS_CMS_ApplicationException;
import com.ponsun.cms.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Slf4j
public class BulkTaskAssignWriteServiceImpl implements BulkTaskAssignWriteService {
    private final BulkTaskAssignRepository bulkTaskAssignRepository;
    private final BulkTaskAssignWrapper bulkTaskAssignWrapper;
    private final BulkTaskAssignValidator bulkTaskAssignValidator;
    private final HitRecordRowMapper hitRecordRowMapper;
    private final JdbcTemplate jdbcTemplate;
    private final BulkAssignMappingWriteService bulkAssignMappingWriteService;
    private final ExcelReadService excelReadService;
    private final BulkAssignMappingValidator bulkAssignMappingValidator;
    private final BulkAssignMappingRepository bulkAssignMappingRepository;


    @Override
    @Transactional
    public Response createBulkTaskAssign(CreateBulkTaskAssignRequest createBulkTaskAssignRequest) {
        try {
            this.bulkTaskAssignValidator.validateSaveBulkTaskAssign(createBulkTaskAssignRequest);
            final BulkTaskAssign bulkTaskAssign = BulkTaskAssign.create(createBulkTaskAssignRequest);
            this.bulkTaskAssignRepository.saveAndFlush(bulkTaskAssign);
            return Response.of(Long.valueOf(bulkTaskAssign.getId()));
        } catch (DataIntegrityViolationException e) {
            log.error("Error creating BulkTaskAssign: {}", e.getMessage(), e);
            throw new EQAS_CMS_ApplicationException("Error creating BulkTaskAssign:" + e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response updateBulkTaskAssign(Integer id, UpdateBulkTaskAssignRequest updateBulkTaskAssignRequest) {
        try {
            this.bulkTaskAssignValidator.validateUpdateBulkTaskAssign(updateBulkTaskAssignRequest);
            final BulkTaskAssign bulkTaskAssign = this.bulkTaskAssignWrapper.findOneWithNotFoundDetection(id);
            bulkTaskAssign.update(updateBulkTaskAssignRequest);
            this.bulkTaskAssignRepository.saveAndFlush(bulkTaskAssign);
            return Response.of(Long.valueOf(bulkTaskAssign.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new EQAS_CMS_ApplicationException(e.getMessage());
        }
    }

    @Override
    @Transactional
    public Response deactive(Integer id, Integer euid) {
        try {
            BulkTaskAssign BulkTaskAssign = this.bulkTaskAssignWrapper.findOneWithNotFoundDetection(id);
            BulkTaskAssign.setEuid(euid);
            BulkTaskAssign.setStatus(Status.DELETE);
            BulkTaskAssign.setUpdatedAt(LocalDateTime.now());
            return Response.of(Long.valueOf(BulkTaskAssign.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new EQAS_CMS_ApplicationException(e.getMessage());
        }
    }

    @Override
    public List<HitRecordData> fetchAllRecordData(Integer searchId) {
        final HitRecordRowMapper rowMapper = new HitRecordRowMapper();
        String Qry = "SELECT " + rowMapper.tableSchema();
        String whereClause = " WHERE hit.searchId = ? ";
        Qry = Qry + whereClause;
        final List<HitRecordData> hitRecordDataList = jdbcTemplate.query(Qry, hitRecordRowMapper,
                new Object[]{searchId}
        );
        return hitRecordDataList;
    }


    @Override
    @Transactional
    public Response createBulkAssign(CreateBulkTaskAssignRequest createBulkTaskAssignRequest) {
        try {
            final BulkTaskAssign bulkTaskAssign = BulkTaskAssign.create(createBulkTaskAssignRequest);
            this.bulkTaskAssignRepository.saveAndFlush(bulkTaskAssign);

            List<Integer> hitIds = this.excelReadService.fetchHitIds(createBulkTaskAssignRequest.getSearchId());

            for (BulkAssignMappingData bulkAssignMappingData : createBulkTaskAssignRequest.getOfacDataList()) {
                RecordDTO recordDTO = createRecordDTO(bulkAssignMappingData, createBulkTaskAssignRequest.getSearchId());
                for (Integer hitId : hitIds) {
                    recordDTO.setHitId(hitId);
                    createAndSaveBulkAssignMapping(recordDTO, bulkTaskAssign.getId());
                }
            }

            return Response.of(Long.valueOf(bulkTaskAssign.getId()));
        } catch (DataIntegrityViolationException e) {
            throw new EQAS_CMS_ApplicationException("Error creating BulkTaskAssign: " + e.getMessage());
        }
    }

    private RecordDTO createRecordDTO(BulkAssignMappingData bulkAssignMappingData, Integer searchId) {
        RecordDTO recordDTO = new RecordDTO();
        recordDTO.setIds(bulkAssignMappingData.getHitId());
        recordDTO.setSearchId(searchId);
        return recordDTO;
    }

    private void createAndSaveBulkAssignMapping(RecordDTO recordDTO, Integer bulkTaskAssignId) {
        CreateBulkAssignMappingRequest createBulkAssignMappingRequest = new CreateBulkAssignMappingRequest();
        createBulkAssignMappingRequest.setBulkAssignId(bulkTaskAssignId);
        createBulkAssignMappingRequest.setSearchId(recordDTO.getSearchId());
        createBulkAssignMappingRequest.setHitId(recordDTO.getHitId());
        createBulkAssignMapping(createBulkAssignMappingRequest);
    }


    @Transactional
    public Response createBulkAssignMapping(CreateBulkAssignMappingRequest createBulkAssignMappingRequest) {
        try {
            this.bulkAssignMappingValidator.validateSaveBulkAssignMapping(createBulkAssignMappingRequest);
            final BulkAssignMapping bulkAssignMapping = BulkAssignMapping.create(createBulkAssignMappingRequest);
            this.bulkAssignMappingRepository.saveAndFlush(bulkAssignMapping);
            return Response.of(Long.valueOf(bulkAssignMapping.getId()));
        } catch (DataIntegrityViolationException e) {
            log.error("Error creating BulkAssignMapping: {}", e.getMessage(), e);
            throw new EQAS_CMS_ApplicationException("Error creating BulkAssignMapping:" + e.getMessage());
        }
    }
}
