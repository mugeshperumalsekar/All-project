package com.ponsun.cms.allDetails.aliases.request;

public class UpdateAliasesRequest extends AbstractAliasesRequest {
    @Override
    public String toString() { return super.toString();}
}
