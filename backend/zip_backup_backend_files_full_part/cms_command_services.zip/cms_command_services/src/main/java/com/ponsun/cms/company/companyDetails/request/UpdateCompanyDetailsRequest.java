package com.ponsun.cms.company.companyDetails.request;

import lombok.Data;

@Data
public class UpdateCompanyDetailsRequest extends AbstractCompanyDetailsRequest {
    @Override
    public String toString(){ return super.toString();}
}
