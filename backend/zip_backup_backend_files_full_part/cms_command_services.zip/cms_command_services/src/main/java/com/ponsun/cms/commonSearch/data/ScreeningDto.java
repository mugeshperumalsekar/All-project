package com.ponsun.cms.commonSearch.data;

import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;
@Data
@RequiredArgsConstructor
public class ScreeningDto {
    private List<SearchDto> searchDto;

    public ScreeningDto(List<SearchDto> searchDto) {
        this.searchDto = searchDto;
    }
    public static ScreeningDto newInstance(List<SearchDto> searchDto){
        return new ScreeningDto(searchDto);
    }
}
