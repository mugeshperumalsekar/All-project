package com.ponsun.cms.adminconfiguration.adminconfigmodule.request;

import lombok.Data;

@Data
public class UpdateAdminConfigModuleRequest extends AbstractAdminConfigModuleBaseRequest{
    @Override
    public String toString() {return super.toString(); }

}