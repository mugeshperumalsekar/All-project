package com.ponsun.pep.adminconfiguration.adminconfigmoduledet.request;

import lombok.Data;

@Data
public class CreateAdminConfigModuleDetRequest extends  AbstractAdminConfigModuleDetBaseRequest{
    @Override
    public String toString() { return super.toString();}
}
