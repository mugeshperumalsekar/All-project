package com.ponsun.pep.familyDetails.FatherDetails.request;

public class CreateFatherDetailsRequest extends  AbstractFatherDetailsRequest{
    @Override
    public String toString() {
        return super.toString();
    }
}
