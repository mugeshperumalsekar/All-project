package com.ponsun.pep.BulkAssignMapping.services;

import com.ponsun.pep.BulkAssignMapping.data.BulkAssignMappingData;
import com.ponsun.pep.BulkAssignMapping.request.CreateBulkAssignMappingRequest;
import com.ponsun.pep.BulkAssignMapping.request.UpdateBulkAssignMappingRequest;
import com.ponsun.pep.infrastructure.utils.Response;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

public interface BulkAssignMappingWriteService {
    Response createBulkAssignMapping(CreateBulkAssignMappingRequest createBulkAssignMappingRequest);
    Response updateBulkAssignMapping(Integer id, UpdateBulkAssignMappingRequest updateBulkAssignMappingRequest);
    Response deactive(Integer id, Integer euid);
    List<BulkAssignMappingData> fetchAllRecordData(Integer searchId);
    List<BulkAssignMappingData> getHitRecordsBySearchId(Integer searchId);
    List<Integer> fetchHitIds(Integer searchId);
}
