package com.ponsun.pep.BulkTaskAssign.request;

import lombok.Data;

@Data
public class UpdateBulkTaskAssignRequest extends AbstractBulkTaskAssignRequest {
    @Override
    public String toString(){ return super.toString();}
}
