package com.ponsun.pep.companiesAndLlp.AssociatedCompanies.request;

import lombok.Data;

@Data
public class CreateAssociatedCompaniesRequest extends AbstractAssociatedCompaniesRequest{
    @Override
    public String toString(){ return super.toString();}
}
