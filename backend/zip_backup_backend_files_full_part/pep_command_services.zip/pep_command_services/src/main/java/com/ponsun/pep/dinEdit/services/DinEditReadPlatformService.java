package com.ponsun.pep.dinEdit.services;

import com.ponsun.pep.dinEdit.domain.DinEdit;

public interface DinEditReadPlatformService {

}
