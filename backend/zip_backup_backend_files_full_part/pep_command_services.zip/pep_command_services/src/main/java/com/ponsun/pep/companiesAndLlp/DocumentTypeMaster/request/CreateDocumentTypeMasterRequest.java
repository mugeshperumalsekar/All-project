package com.ponsun.pep.companiesAndLlp.DocumentTypeMaster.request;
public class CreateDocumentTypeMasterRequest extends AbstractDocumentTypeMasterRequest {
    @Override
    public String toString(){
        return super.toString();
    }
}
