package com.ponsun.pep.companiesAndLlp.CompanyAssociation.request;

import lombok.Data;

@Data
public class CreateCompanyAssociationRequest extends AbstractCompanyAssociationRequest {
    @Override
    public String toString(){ return super.toString();}
}
