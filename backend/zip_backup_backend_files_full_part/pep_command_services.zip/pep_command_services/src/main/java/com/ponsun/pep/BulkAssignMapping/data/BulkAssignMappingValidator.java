package com.ponsun.pep.BulkAssignMapping.data;


import com.ponsun.pep.BulkAssignMapping.request.CreateBulkAssignMappingRequest;
import com.ponsun.pep.BulkAssignMapping.request.UpdateBulkAssignMappingRequest;
import com.ponsun.pep.infrastructure.exceptions.EQAS_PEP_AppicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BulkAssignMappingValidator {
    public void validateSaveBulkAssignMapping(final CreateBulkAssignMappingRequest request){
        if(request.getSearchId() == null || request.getSearchId().equals("")){
            throw  new EQAS_PEP_AppicationException("BulkAssignMappingTo parameter required");
        }
        if(request.getSearchId() == null || request.getSearchId().equals("")){
            throw new EQAS_PEP_AppicationException("BulkAssignMappingBy parameter required");
        }
    }

    public void validateUpdateBulkAssignMapping(final UpdateBulkAssignMappingRequest request){
        if(request.getSearchId() == null || request.getSearchId().equals("")){
            throw new EQAS_PEP_AppicationException("BulkAssignMappingTo parameter required");
        }
        if(request.getSearchId() == null || request.getSearchId().equals("")){
            throw new EQAS_PEP_AppicationException("BulkAssignMappingBy parameter required");
        }
    }
}
