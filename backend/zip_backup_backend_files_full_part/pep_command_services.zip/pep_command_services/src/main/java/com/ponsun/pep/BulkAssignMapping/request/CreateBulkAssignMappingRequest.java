package com.ponsun.pep.BulkAssignMapping.request;

import lombok.Data;

@Data
public class CreateBulkAssignMappingRequest extends AbstractBulkAssignMappingRequest {
    @Override
    public String toString(){ return super.toString();}
}
