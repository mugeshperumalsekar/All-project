package com.ponsun.pep.dinEdit.request;

import lombok.Data;

@Data
public class CreateDinEditRequest extends AbstractDinEditRequest{
    @Override
    public String toString() {return super.toString();}
}
