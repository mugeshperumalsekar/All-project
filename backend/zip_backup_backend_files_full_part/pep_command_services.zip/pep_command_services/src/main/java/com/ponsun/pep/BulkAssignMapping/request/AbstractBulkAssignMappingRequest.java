package com.ponsun.pep.BulkAssignMapping.request;

import lombok.Data;

@Data
public class AbstractBulkAssignMappingRequest {
    private  Integer bulkAssignId;
    private Integer searchId;
    private Integer hitId;
    private Integer euid;
    private Integer uid;
}
