package com.ponsun.pep.BulkTaskAssign.data;

import lombok.Data;

@Data
public class BulkTaskAssignData {
    private  Integer assignTo;
    private Integer assignBy;
    private String searchName;
    private Integer searchId;
    private Integer euid;
    private Integer uid;

    public BulkTaskAssignData(Integer assignTo, Integer assignBy,String searchName ,Integer searchId, Integer euid, Integer uid) {
        this.assignTo = assignTo;
        this.assignBy = assignBy;
        this.searchName = searchName;
        this.searchId = searchId;
        this.euid = euid;
        this.uid = uid;

    }

    public static BulkTaskAssignData newInstance(Integer assignTo, Integer assignBy, String searchName ,Integer searchId, Integer euid, Integer uid) {
        return new BulkTaskAssignData(assignTo, assignBy,searchName,searchId, euid, uid);
    }
}
