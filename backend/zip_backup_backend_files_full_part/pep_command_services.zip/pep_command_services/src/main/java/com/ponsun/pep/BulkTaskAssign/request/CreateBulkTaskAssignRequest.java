package com.ponsun.pep.BulkTaskAssign.request;

import lombok.Data;

@Data
public class CreateBulkTaskAssignRequest extends AbstractBulkTaskAssignRequest {
    @Override
    public String toString(){ return super.toString();}
}
