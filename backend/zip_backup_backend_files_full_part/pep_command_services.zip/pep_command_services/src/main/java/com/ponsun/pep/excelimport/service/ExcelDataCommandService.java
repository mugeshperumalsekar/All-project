package com.ponsun.pep.excelimport.service;

import com.ponsun.pep.EhcachePOC.Data.OFACData;
import com.ponsun.pep.EhcachePOC.Service.OFACSearchService;
import com.ponsun.pep.Search.data.RecordDTO;
import com.ponsun.pep.Search.services.SearchReadPlatformService;
import com.ponsun.pep.Search.services.SearchWritePlatformService;
import com.ponsun.pep.algorithm.ScoringCalculator;
import com.ponsun.pep.customerDetails.data.CustomerDetailsData;
import com.ponsun.pep.customerDetails.services.CustomerDetailsWritePlatformService;
import com.ponsun.pep.dto.ScreenDTO;
import com.ponsun.pep.dto.SearchDTO;
import com.ponsun.pep.excelimport.dto.ExcelDataDto;
import com.ponsun.pep.excelimport.entity.ExcelData;
import com.ponsun.pep.excelimport.repository.ExcelDataRepository;
import com.ponsun.pep.infrastructure.exceptions.EQAS_PEP_AppicationException;
import com.ponsun.pep.infrastructure.utils.Response;
import com.ponsun.pep.searchDetails.request.CreateSearchDetailsRequest;
import com.ponsun.pep.searchDetails.service.SearchDetailsWritePlatformService;
import com.ponsun.pep.searchLifcycle.searchResult.services.SearchResultWritePlatformService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.*;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Service
@Slf4j
@RequiredArgsConstructor
public class ExcelDataCommandService {

    private final ExcelDataRepository excelDataRepository;
    private final OFACSearchService ofacsearchService;
    private final ScoringCalculator scoringCalculator;
    private final CustomerDetailsWritePlatformService customerDetailsWritePlatformService;
    private final SearchDetailsWritePlatformService searchDetailsWritePlatformService;
    private final SearchWritePlatformService searchWritePlatformService;
    private final SearchResultWritePlatformService searchResultWritePlatformService;
    private final SearchReadPlatformService searchReadPlatformService;


    public ExcelData save(ExcelDataDto input) {
        ExcelData excelData = new ExcelData();
        excelData.setName(input.getName());
        excelData.setType(input.getType());
        excelData.setScore(input.getScore());
        excelData.setCountry(input.getCountry());
        return excelDataRepository.save(excelData);
    }
    @Transactional
    public Response saveBulkData(List<Map<String, Object>> rows) {
        try {
            long totalRecordSaved = 0L;
            long startTime = System.currentTimeMillis();

            List<ScreenDTO> screenDTOList = new ArrayList<>();

            for (Map<String, Object> row : rows) {
                final String name = getStringValue(row.get("name"));
                final Object scoreObject = row.get("score");
                final double parsedScore = getDoubleValue(scoreObject);
                ScreenDTO screenDTO = new ScreenDTO();
                screenDTO.setName(name);
                screenDTO.setSearchingScore(Double.parseDouble(String.valueOf(parsedScore)));
                screenDTOList.add(screenDTO);
                totalRecordSaved = totalRecordSaved + 1;
            }

            this.searchReadPlatformService.getpepRecords(screenDTOList);
            List<CustomerDetailsData> customerDetailsData = this.customerDetailsWritePlatformService.fetchAllCustomerDetailsData();
            this.scoringCalculator.calculateScore(screenDTOList, customerDetailsData);

            return new Response(totalRecordSaved);

        } catch (DataIntegrityViolationException e) {
            log.error("Error while saveBulkData {}", e.getMessage());
            throw new EQAS_PEP_AppicationException(e.getMessage());
        }
    }

    private String getStringValue(Object value) {
        if (value instanceof String) {
            return ((String) value).trim();
        } else if (value instanceof Double) {
            return String.valueOf(value);
        } else {
            return "";
        }
    }

    private double getDoubleValue(Object value) {
        if (value instanceof String) {
            try {
                return Double.parseDouble((String) value);
            } catch (NumberFormatException e) {
                return 0.0;
            }
        } else if (value instanceof Double) {
            return (Double) value;
        } else {
            return 0.0;
        }
    }


//    @Transactional
//    public Response saveKycScreeningData(List<ScreenDTO> screenDTOList) {
//        try {
//            long totalRecordSaved = 0L;
//            long startTime = System.currentTimeMillis();
//
//            List<OFACData> ofacdataList = this.ofacsearchService.fetchAllOFACData();
//
//            // Filter out duplicates in screenDTOList based on name
//            Set<String> uniqueNames = new HashSet<>();
//            List<ScreenDTO> filteredList = screenDTOList.stream()
//                    .filter(screenDTO -> uniqueNames.add(screenDTO.getName()))
//                    .collect(Collectors.toList());
//
//            for (ScreenDTO screenDTO : filteredList) {
//                CreateSearchDetailsRequest createSearchDetailsRequest = new CreateSearchDetailsRequest();
//                createSearchDetailsRequest.setName(screenDTO.getName());
//                createSearchDetailsRequest.setMatchingScore(screenDTO.getSearchingScore());
//                createSearchDetailsRequest.setKycId(screenDTO.getKycId());
//                createSearchDetailsRequest.setUid(screenDTO.getUid());
//                createSearchDetailsRequest.setApplicantId(screenDTO.getApplicantFormId());
//                searchDetailsWritePlatformService.createSearchDetails(createSearchDetailsRequest);
//
//            }
//
//            this.excelReadService.calculateScores(filteredList, ofacdataList);
//
//            long endTime = System.currentTimeMillis();
//            System.out.println("Total milliseconds taken " + (endTime - startTime));
//            return new Response(totalRecordSaved);
//        } catch (DataIntegrityViolationException e) {
//            log.error("Error while saving data {}", e.getMessage());
//            throw new EQAS_PEP_AppicationException(e.getMessage());
//        } catch (ExecutionException | InterruptedException e) {
//            throw new RuntimeException(e);
//        }
//    }
    ///////////////////////////////
//
}

