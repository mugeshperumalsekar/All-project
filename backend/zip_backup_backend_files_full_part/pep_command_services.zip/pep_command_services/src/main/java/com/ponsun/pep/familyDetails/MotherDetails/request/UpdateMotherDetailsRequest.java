package com.ponsun.pep.familyDetails.MotherDetails.request;

public class UpdateMotherDetailsRequest extends AbstractMotherDetailsRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}
