package com.ponsun.pep.familyDetails.FatherDetails.request;

public class UpdateFatherDetailsRequest  extends AbstractFatherDetailsRequest{
    @Override
    public String toString() {
        return super.toString();
    }
}
