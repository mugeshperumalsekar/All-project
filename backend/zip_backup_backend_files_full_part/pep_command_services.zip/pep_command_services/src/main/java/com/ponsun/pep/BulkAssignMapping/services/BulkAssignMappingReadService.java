package com.ponsun.pep.BulkAssignMapping.services;

import com.ponsun.pep.BulkAssignMapping.domain.BulkAssignMapping;

import java.util.List;

public interface BulkAssignMappingReadService {
    List<BulkAssignMapping> fetchAllBulkAssignMapping();

    BulkAssignMapping fetchBulkAssignMappingById(Integer id);
}
