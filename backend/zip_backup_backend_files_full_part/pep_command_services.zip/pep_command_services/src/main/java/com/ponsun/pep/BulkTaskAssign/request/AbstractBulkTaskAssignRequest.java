package com.ponsun.pep.BulkTaskAssign.request;

import com.ponsun.pep.BulkAssignMapping.data.BulkAssignMappingData;
import lombok.Data;

import java.util.List;

@Data
public class AbstractBulkTaskAssignRequest {
    private  Integer assignTo;
    private Integer assignBy;
    private String searchName;
    private Integer searchId;
    private Integer euid;
    private Integer uid;
    private List<BulkAssignMappingData> ofacDataList;
}
