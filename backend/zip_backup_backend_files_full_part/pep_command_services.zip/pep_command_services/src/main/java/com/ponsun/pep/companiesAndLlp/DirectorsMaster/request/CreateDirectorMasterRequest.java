package com.ponsun.pep.companiesAndLlp.DirectorsMaster.request;

import lombok.Data;

@Data
public class CreateDirectorMasterRequest extends AbstractDirectorMasterRequest{

    @Override
    public String toString(){
        return super.toString();
    }
}
