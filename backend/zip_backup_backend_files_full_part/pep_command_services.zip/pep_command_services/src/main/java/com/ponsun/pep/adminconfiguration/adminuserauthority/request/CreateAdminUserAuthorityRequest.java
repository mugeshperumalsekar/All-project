package com.ponsun.pep.adminconfiguration.adminuserauthority.request;

public class CreateAdminUserAuthorityRequest extends AbstractAdminUserAuthorityBaseRequest {
    @Override
    public String toString() {return super.toString();}
}
