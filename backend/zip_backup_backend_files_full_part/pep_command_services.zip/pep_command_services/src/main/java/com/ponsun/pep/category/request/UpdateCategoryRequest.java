package com.ponsun.pep.category.request;

public class UpdateCategoryRequest extends AbstractCategoryRequest{
    @Override
    public String toString() {
        return super.toString();
    }
}
