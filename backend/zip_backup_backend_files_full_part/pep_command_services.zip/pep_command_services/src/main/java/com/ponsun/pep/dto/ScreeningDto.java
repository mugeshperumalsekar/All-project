package com.ponsun.pep.dto;
import lombok.Data;
import lombok.RequiredArgsConstructor;

import java.util.List;
@Data
@RequiredArgsConstructor
public class ScreeningDto {
    private List<ScreenDTO> screenDTOList;

    public ScreeningDto(List<ScreenDTO> screenDTOList) {
        this.screenDTOList = screenDTOList;
    }
    public static ScreeningDto newInstance(List<ScreenDTO> screenDTOList) {
        return new ScreeningDto(screenDTOList);
    }
}
