package com.ponsun.pep.BulkTaskAssign.services;

import com.ponsun.pep.BulkTaskAssign.request.CreateBulkTaskAssignRequest;
import com.ponsun.pep.BulkTaskAssign.request.UpdateBulkTaskAssignRequest;
import com.ponsun.pep.infrastructure.utils.Response;
import com.ponsun.pep.searchLifcycle.HitRecord.data.HitRecordData;

import java.util.List;

public interface BulkTaskAssignWriteService {
    Response createBulkTaskAssign(CreateBulkTaskAssignRequest createBulkTaskAssignRequest);

    Response updateBulkTaskAssign(Integer id, UpdateBulkTaskAssignRequest updateBulkTaskAssignRequest);

    Response deactive(Integer id, Integer euid);

    List<HitRecordData> fetchAllRecordData(Integer searchId);

    Response createBulkAssign(CreateBulkTaskAssignRequest createBulkTaskAssignRequest);
}
