package com.ponsun.pep.FilesStorage.request;

import lombok.Data;

@Data
public class CreateFileStorageRequest extends AbstractFileStorageRequest {

    @Override
    public String toString() {
        return super.toString();
    }
}
