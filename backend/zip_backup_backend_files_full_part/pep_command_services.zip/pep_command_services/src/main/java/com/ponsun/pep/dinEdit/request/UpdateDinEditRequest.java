package com.ponsun.pep.dinEdit.request;

import lombok.Data;

@Data
public class UpdateDinEditRequest extends AbstractDinEditRequest{
    @Override
    public String toString() {return super.toString();}
}
