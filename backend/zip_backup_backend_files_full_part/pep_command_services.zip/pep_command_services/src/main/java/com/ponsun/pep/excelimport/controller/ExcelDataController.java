package com.ponsun.pep.excelimport.controller;

import com.ponsun.pep.dto.ScreenDTO;
import com.ponsun.pep.excelimport.fileupload.XlsFileParser;
import com.ponsun.pep.excelimport.service.ExcelDataCommandService;
import com.ponsun.pep.infrastructure.utils.Response;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/excel")
@RequiredArgsConstructor
@Slf4j
public class ExcelDataController {

    private final ExcelDataCommandService excelDataCommandService;
    @PostMapping("/tableBulkImport")
    public Response tableBulkImport(@RequestParam("file") MultipartFile file) {
        log.debug("Received file upload request");
        XlsFileParser xlsFileParser = new XlsFileParser();
        List<Map<String, Object>> data = xlsFileParser.parseExcelDataFromStream(file);
        Response response = excelDataCommandService.saveBulkData(data);
        log.debug("File processed successfully");
        return response;
    }
}























