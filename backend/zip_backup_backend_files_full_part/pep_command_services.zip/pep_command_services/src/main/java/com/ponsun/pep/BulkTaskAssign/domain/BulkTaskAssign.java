package com.ponsun.pep.BulkTaskAssign.domain;


import com.ponsun.pep.BulkTaskAssign.request.CreateBulkTaskAssignRequest;
import com.ponsun.pep.BulkTaskAssign.request.UpdateBulkTaskAssignRequest;
import com.ponsun.pep.common.entity.Status;
import com.ponsun.pep.infrastructure.baseentity.BaseEntity;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "san_bulk_task_assign")
public class BulkTaskAssign extends BaseEntity {
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "id", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "assignTo")
    private Integer assignTo;

    @Column(name = "assignBy")
    private Integer assignBy;

    @Column(name = "searchName")
    private String searchName;

    @Column(name = "searchId")
    private Integer searchId;

    @Column(name = "uid")
    private Integer uid;

    @Column(name = "euid")
    private Integer euid;

    public static BulkTaskAssign create(final CreateBulkTaskAssignRequest createBulkTaskAssignRequest) {
        final BulkTaskAssign BulkTaskAssign = new BulkTaskAssign();
        BulkTaskAssign.setAssignTo(createBulkTaskAssignRequest.getAssignTo());
        BulkTaskAssign.setAssignBy(createBulkTaskAssignRequest.getAssignBy());
        BulkTaskAssign.setSearchName(createBulkTaskAssignRequest.getSearchName());
        BulkTaskAssign.setSearchId(createBulkTaskAssignRequest.getSearchId());
        BulkTaskAssign.setUid(createBulkTaskAssignRequest.getUid());
        BulkTaskAssign.setStatus(Status.ACTIVE);
        BulkTaskAssign.setCreatedAt(LocalDateTime.now());
        return BulkTaskAssign;
    }

    public void update(final UpdateBulkTaskAssignRequest updateBulkTaskAssignRequest) {
        this.setAssignTo(updateBulkTaskAssignRequest.getAssignTo());
        this.setAssignBy(updateBulkTaskAssignRequest.getAssignBy());
        this.setSearchName(updateBulkTaskAssignRequest.getSearchName());
        this.setSearchId(updateBulkTaskAssignRequest.getSearchId());
        this.setUid(updateBulkTaskAssignRequest.getUid());
        this.setStatus(Status.ACTIVE);
        this.setUpdatedAt(LocalDateTime.now());
    }

}
