package com.ponsun.pep.companiesAndLlp.AssociatedCompaniesContactDet.request;

public class UpdateAssCompanyContactDetRequest extends AbstractAssCompanyContactDetRequest {
    @Override
    public String toString() { return super.toString(); }
}
