package com.ponsun.pep.companiesAndLlp.CompanyDocuments.request;

import lombok.Data;

@Data
public class CreateCompanyDocumentsRequest extends AbstractCompanyDocumentsRequest {
    @Override
    public String toString() {
        return super.toString();
    }

}
