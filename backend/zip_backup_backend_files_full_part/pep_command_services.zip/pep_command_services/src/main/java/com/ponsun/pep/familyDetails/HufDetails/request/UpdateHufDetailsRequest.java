package com.ponsun.pep.familyDetails.HufDetails.request;

public class UpdateHufDetailsRequest extends AbstractHufDetailsRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}