package com.ponsun.pep.BulkTaskAssign.data;


import com.ponsun.pep.BulkTaskAssign.request.CreateBulkTaskAssignRequest;
import com.ponsun.pep.BulkTaskAssign.request.UpdateBulkTaskAssignRequest;
import com.ponsun.pep.infrastructure.exceptions.EQAS_PEP_AppicationException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BulkTaskAssignValidator {
    public void validateSaveBulkTaskAssign(final CreateBulkTaskAssignRequest request){
        if(request.getAssignTo() == null || request.getAssignTo().equals("")){
            throw  new EQAS_PEP_AppicationException("BulkTaskAssignTo parameter required");
        }
    }

    public void validateUpdateBulkTaskAssign(final UpdateBulkTaskAssignRequest request){
        if(request.getAssignTo() == null || request.getAssignTo().equals("")){
            throw new EQAS_PEP_AppicationException("BulkTaskAssignTo parameter required");
        }
    }
}
