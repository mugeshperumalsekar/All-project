touch .gitignore

cd existing_repo
git remote add origin https://gitlab.com/SAN_services/SAN_command_services.git
git branch -M main
git push -uf origin main

git push to an existing repo

STEP -1 :
    cd existing_repo
    git remote rm origin

STEP -2 :
    git remote add origin https://gitlab.com/SAN_services/SAN_command_services.git
    git branch -M main
    git checkout -b develop
    git push origin develop


