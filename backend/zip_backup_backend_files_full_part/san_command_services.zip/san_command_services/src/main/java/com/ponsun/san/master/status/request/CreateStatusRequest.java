package com.ponsun.san.master.status.request;

public class CreateStatusRequest extends AbstractStatusBaseRequest {
    @Override
    public String toString() {
        return super.toString();
    }

}