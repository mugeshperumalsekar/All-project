package com.ponsun.san.master.country.request;

import lombok.Data;

@Data
public class CreateCountryRequest extends AbstractCountryRequest {

    @Override
    public String toString() {
        return  super.toString();
    }
}
