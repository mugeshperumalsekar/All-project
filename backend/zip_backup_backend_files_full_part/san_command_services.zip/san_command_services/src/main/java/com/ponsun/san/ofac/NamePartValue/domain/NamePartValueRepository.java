//package com.ponsun.san.ofac.NamePartValue.domain;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//public interface NamePartValueRepository extends JpaRepository<NamePartValue, Integer> {
//}
