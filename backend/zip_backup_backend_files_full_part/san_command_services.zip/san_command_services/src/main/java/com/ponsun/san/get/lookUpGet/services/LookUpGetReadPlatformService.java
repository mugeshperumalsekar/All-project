package com.ponsun.san.get.lookUpGet.services;

public interface LookUpGetReadPlatformService {
}
