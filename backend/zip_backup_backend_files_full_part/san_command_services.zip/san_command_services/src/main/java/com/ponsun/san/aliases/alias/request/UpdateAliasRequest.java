package com.ponsun.san.aliases.alias.request;

import lombok.Data;

@Data
public class UpdateAliasRequest extends AbstractAliasRequest {
    public String toString() {
        return super.toString();
    }
}