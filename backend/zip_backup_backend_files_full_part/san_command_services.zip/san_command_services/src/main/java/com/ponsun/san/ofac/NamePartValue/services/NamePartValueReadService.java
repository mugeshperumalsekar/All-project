//package com.ponsun.san.ofac.NamePartValue.services;
//
//import com.ponsun.san.dto.RecordDTO;
//import com.ponsun.san.dto.SearchDTO;
//import com.ponsun.san.ofac.NamePartValue.domain.NamePartValue;
//
//import java.util.List;
//
//public interface NamePartValueReadService {
//    NamePartValue fetchNamePartValueById(Integer id);
//    List<NamePartValue> fetchAllNamePartValue();
//    List<RecordDTO> fetchAllCustomerList(final SearchDTO searchDTO);
//}
