package com.ponsun.san.FilesStorage.request;

import lombok.Data;

@Data
public class CreateFileStorageRequest extends AbstractFileStorageRequest {

    @Override
    public String toString() {
        return super.toString();
    }
}
