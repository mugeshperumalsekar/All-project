package com.ponsun.san.master.levelMapping.request;

public class UpdateLevelMappingRequest extends AbstractLevelMappingRequest{
    @Override
    public String toString() {
        return super.toString();
    }
}
