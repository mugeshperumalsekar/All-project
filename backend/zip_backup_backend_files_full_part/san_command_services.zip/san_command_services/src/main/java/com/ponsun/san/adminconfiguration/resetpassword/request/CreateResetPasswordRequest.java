package com.ponsun.san.adminconfiguration.resetpassword.request;

import lombok.Data;

@Data
public class CreateResetPasswordRequest extends AbstractResetPasswordBaseRequest {
    @Override
    public String toString() {
        return super.toString();
    }

}
