package com.ponsun.san.aliases.aliasType.request;

import lombok.Data;

@Data
public class CreateAliasTypeRequest extends AbstractAliasTypeRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}
