package com.ponsun.san.master.level.request;

import lombok.Data;

@Data
public class AbstractLevelRequest {
    private String name;
    private Integer uid;
}
