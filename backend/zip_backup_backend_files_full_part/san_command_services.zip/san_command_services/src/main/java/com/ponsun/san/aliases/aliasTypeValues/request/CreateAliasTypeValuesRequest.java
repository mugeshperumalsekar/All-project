package com.ponsun.san.aliases.aliasTypeValues.request;

public class CreateAliasTypeValuesRequest extends AbstractAliasTypeValuesRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}
