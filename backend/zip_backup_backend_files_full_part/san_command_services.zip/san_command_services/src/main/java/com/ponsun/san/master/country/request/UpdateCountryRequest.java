package com.ponsun.san.master.country.request;

public class UpdateCountryRequest extends AbstractCountryRequest {

    @Override
    public String toString() {
        return  super.toString();
    }
}
