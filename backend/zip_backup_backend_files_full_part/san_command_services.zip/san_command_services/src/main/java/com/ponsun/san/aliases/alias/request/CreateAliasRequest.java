package com.ponsun.san.aliases.alias.request;

import lombok.Data;

@Data
public class CreateAliasRequest extends AbstractAliasRequest {
    public String toString() {
        return super.toString();
    }
}
