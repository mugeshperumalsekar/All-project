package com.ponsun.san.master.level.request;

import lombok.Data;

@Data
public class CreateLevelRequest extends  AbstractLevelRequest{
    @Override
    public String toString() {
        return  super.toString();
    }
}
