package com.ponsun.san.FilesStorage.request;

public class UpdateFileStorageRequest {
    @Override
    public String toString() {
        return super.toString();
    }

}
