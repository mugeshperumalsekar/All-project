package com.ponsun.san.adminconfiguration.adminconfigmodule.request;

import lombok.Data;

@Data
public class UpdateAdminConfigModuleRequest extends AbstractAdminConfigModuleBaseRequest{
    @Override
    public String toString() {return super.toString(); }

}