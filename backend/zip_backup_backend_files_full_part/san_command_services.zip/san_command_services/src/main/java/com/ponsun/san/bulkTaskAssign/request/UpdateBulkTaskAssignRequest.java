package com.ponsun.san.bulkTaskAssign.request;

import lombok.Data;

@Data
public class UpdateBulkTaskAssignRequest extends AbstractBulkTaskAssignRequest {
    @Override
    public String toString(){ return super.toString();}
}
