package com.ponsun.san.adminconfiguration.adminconfigmoduledet.request;

import lombok.Data;

@Data
public class CreateAdminConfigModuleDetRequest extends  AbstractAdminConfigModuleDetBaseRequest{
    @Override
    public String toString() { return super.toString();}
}
