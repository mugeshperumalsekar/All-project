package com.ponsun.san.master.sanctionsProgram.request;

public class UpdateSanctionsProgramRequest extends AbstractSanctionsProgramRequest {

    @Override
    public String toString() {
        return super.toString();
    }
}
