package com.ponsun.san.FilesStorage.data;

public class FileStorageDataValidator {
}
