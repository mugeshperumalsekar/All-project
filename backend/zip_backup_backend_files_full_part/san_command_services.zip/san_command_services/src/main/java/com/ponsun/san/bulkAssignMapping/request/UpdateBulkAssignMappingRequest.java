package com.ponsun.san.bulkAssignMapping.request;

import lombok.Data;

@Data
public class UpdateBulkAssignMappingRequest extends AbstractBulkAssignMappingRequest {
    @Override
    public String toString(){ return super.toString();}
}
