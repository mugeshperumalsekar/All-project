package com.ponsun.san.ruleengine.exception;

public abstract class AbstractRuleEngineException extends Exception {

    public AbstractRuleEngineException(String message) {
        super(message);
    }
}
