//package com.ponsun.san.ofac.NamePartValue.request;
//
//import lombok.Data;
//
//@Data
//public class CreateNamePartValueRequest extends AbstractNamePartValueRequest{
//    @Override
//    public String toString(){
//        return super.toString();
//    }
//}
