package com.ponsun.san.sanction.nameDetails.request;


import lombok.Data;

@Data
public class CreateNameDetailsRequest extends AbstractNameDetailsRequest {
    public String toString() {
        return super.toString();
    }
}
