package com.ponsun.san.sanction.nameDetails.request;

import lombok.Data;

@Data
public class AbstractNameDetailsRequest {
    private String Title;
    private String Name_1;
    private String Gender;
    private String DOB;
    private String Town_of_Birth;
}
