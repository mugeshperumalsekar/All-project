package com.ponsun.san.sanction.nameDetails.request;

import lombok.Data;

@Data
public class UpdateNameDetailsRequest extends AbstractNameDetailsRequest {
    public String toString() {
        return super.toString();
    }
}
