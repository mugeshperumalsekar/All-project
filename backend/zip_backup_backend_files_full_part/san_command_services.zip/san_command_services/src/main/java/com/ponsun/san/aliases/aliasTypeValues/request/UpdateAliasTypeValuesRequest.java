package com.ponsun.san.aliases.aliasTypeValues.request;

import lombok.Data;

@Data
public class UpdateAliasTypeValuesRequest extends AbstractAliasTypeValuesRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}
