package com.ponsun.san.master.statusMapping.request;



public class CreateStatusMappingRequest extends AbstractStatusMappingRequest {
    @Override
    public String toString() {
        return super.toString();
    }
}
