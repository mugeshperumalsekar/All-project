package com.ponsun.san.ruleengine.exception;

public class RuleFailedException extends AbstractRuleEngineException {

    public RuleFailedException(String message) {
        super(message);
    }
}
