//package com.ponsun.san.ofac.NamePartValue.request;
//
//import lombok.Data;
//
//@Data
//public class AbstractNamePartValueRequest {
//    private Integer PrimaryKey;
//    private String NamePartGroupID;
//    private String ScriptID;
//    private String ScriptStatusID;
//    private String Acronym;
//    private String Text;
//    private String FK_DocumentedNamePart;
//}
