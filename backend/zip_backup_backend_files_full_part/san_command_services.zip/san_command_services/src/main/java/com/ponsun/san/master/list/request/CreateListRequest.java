package com.ponsun.san.master.list.request;

import lombok.Data;

@Data
public class CreateListRequest extends AbstractListRequest {

    @Override
    public String toString() {
        return super.toString();
    }
}
