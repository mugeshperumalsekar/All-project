package com.ponsun.san.aliases.aliasTypeValues.request;

import lombok.Data;

@Data
public class AbstractAliasTypeValuesRequest {

    private String PrimaryKey;
    private String FK_ReferenceValueSets;

}
