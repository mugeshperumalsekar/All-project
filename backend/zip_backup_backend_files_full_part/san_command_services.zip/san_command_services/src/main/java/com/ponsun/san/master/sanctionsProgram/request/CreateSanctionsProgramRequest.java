package com.ponsun.san.master.sanctionsProgram.request;

import lombok.Data;

@Data
public class CreateSanctionsProgramRequest extends AbstractSanctionsProgramRequest {

    @Override
    public String toString() {
        return super.toString();
    }
}
