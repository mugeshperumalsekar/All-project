package com.ponsun.san.master.levelMapping.request;

public class CreateLevelMappingRequest extends AbstractLevelMappingRequest{
    @Override
    public String toString() {
        return super.toString();
    }
}
