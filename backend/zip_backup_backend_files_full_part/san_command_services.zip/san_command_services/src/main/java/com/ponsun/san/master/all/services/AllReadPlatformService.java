package com.ponsun.san.master.all.services;

import com.ponsun.san.master.all.data.AllData;

import java.util.List;

public interface AllReadPlatformService {
    List<AllData> fetchAllAllData();
}
