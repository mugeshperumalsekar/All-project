interface ApplicationState{
    saveApplicationReducer:any;
    saveDeclarationReducer:any;
}
export default ApplicationState;

