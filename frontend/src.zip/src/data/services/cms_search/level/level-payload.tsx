export interface LevelPayload {
    name: string;
    uid:number;
  }; 