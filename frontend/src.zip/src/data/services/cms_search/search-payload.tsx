export interface SearchPayload {
  name: string;
  typeId: string;
  stateId: string;
  countryId: string;
  identity: string;
  uid: string;
};