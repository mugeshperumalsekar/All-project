export interface LevelStatusMappingPayload {
 
    levelId: number,
    statusId: number,
    uid: number
  }
  
  