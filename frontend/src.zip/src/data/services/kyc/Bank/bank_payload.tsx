export interface BankData {
    fromDate: string;
    toDate: string;
    kycId: number;
    name: string;
    date: string;
}