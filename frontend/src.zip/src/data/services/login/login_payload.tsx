export interface HeaderPayload {
    name: string;
    code: string;
    link: string;
    uid: string;
    id: string;
};