 export interface RolePermissionRequest {
    uid:string;
    modId: number;
    modDetId: number;
    entUid: number;
    valid: boolean;
    euid: number;
    roleId: string;
  }