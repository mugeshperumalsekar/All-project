export interface MaritalStatusPayload {
    name: string;
    prefix:string;
  }
  



  