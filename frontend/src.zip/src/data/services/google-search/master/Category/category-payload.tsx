export interface CategoryPayload {
    groupId: string;
    name: string;
    includeOrExclude:string;

}

