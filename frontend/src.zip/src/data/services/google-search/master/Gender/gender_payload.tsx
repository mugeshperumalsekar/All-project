export interface GenderPayload {
  title: string;
  gender:string;
}
