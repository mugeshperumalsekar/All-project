export interface AdminPayload {
   
    groupId: number;
    categoryId:number;
    clientId:number;
}
