export interface ClientPayload {
   
    groupId: number;
    categoryId: number;
    clientId: number;
    userId: number;
    
}
