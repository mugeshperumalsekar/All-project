export interface GroupPayload {

    name: string;
}