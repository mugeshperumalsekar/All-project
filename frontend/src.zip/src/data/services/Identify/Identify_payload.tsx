export interface Identifieds {
    cmsId: number;
    userName: string;
    cmsName: string;
    recordTypeId: number;
    sourceLink: string;
    genderId: number;
    uid: number;
}