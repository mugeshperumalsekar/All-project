export interface uiCountryDtoVerify {
  name1: string,
  name2: string,
  id1: string,
  id2: string,
  country1: string[],
  country2: string[],
  dob1: string,
  dob2: string,
  entityType: number,
}