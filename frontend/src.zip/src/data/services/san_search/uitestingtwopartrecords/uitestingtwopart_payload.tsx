export interface uiReciveTwoPartRecord {
    initials: number;
    twoside: number;
    jarowinkler: string;
    daitchMokotoffJW: number;
    soundX_JW: string;
    beiderMorseJW: number;
    fuzzyWuzzyWR: string;
    jw_n:number;
    jwtoken:number;
    fwwr:number;
    fwwrtoken:number;
    soundex_withouttoken_fuzzy:number;
    soundex_withouttoken_JW:number;

    
 }