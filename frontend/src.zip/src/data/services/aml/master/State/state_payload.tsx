export interface StatePayload {
    stateName: string;
    countryId: string;
}
