interface Country {
  id: string;
  name: string;
}

export default Country;