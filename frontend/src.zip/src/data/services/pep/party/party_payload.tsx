// Replace 'interface' with 'type' if you prefer using a type alias
export interface PartyPayload {
   partyName: string;
  }
  