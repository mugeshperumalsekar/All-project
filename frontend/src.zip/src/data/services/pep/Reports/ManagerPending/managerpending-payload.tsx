export interface ManagerPendingData {
    frmDate: string;
      toDate: string;
      count: string;
  }