export interface QcEditData {
    frmDate: string;
      toDate: string;
      name: string;
      count: string;
  }