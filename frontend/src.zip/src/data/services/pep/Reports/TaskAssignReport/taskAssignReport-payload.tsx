export interface TaskAssignReport{
    frmDate: string;
    toDate: string;
    country: string;
    state: string;
    year : string;
    uid : string;
}