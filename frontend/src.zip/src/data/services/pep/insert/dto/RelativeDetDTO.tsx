interface RelativeDetDTO {
    pepId: number;
    relativeId: number;
    name: string;
    pan: string;
  }
  export default RelativeDetDTO;