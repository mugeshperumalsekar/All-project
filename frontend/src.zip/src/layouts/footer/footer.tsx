import React from 'react'

const footer = () => {
    return (
        <div>footer</div>
    )
}

export default footer